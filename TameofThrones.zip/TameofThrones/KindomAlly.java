package Practice;

import java.util.ArrayList;

public class KindomAlly {
	private ArrayList<String> allies;
	
	public KindomAlly() {
		allies = new ArrayList<String>();
	}
	
	public void validateAllies(ArrayList<Kingdom> kingdoms) {
		Ally ally = new Ally();
		for (Kingdom kingdom : kingdoms) {
			if (ally.isAlly(kingdom.getName(), kingdom.getMessage())) {
				allies.add(kingdom.getName());
			}
		}
	}
	
	public void PrintAllies() {
		if(allies.size()>=Constants.MIN_ALLIES) {
			System.out.println(allies);
		} else {
			System.out.println(Constants.NONE);
		}
	}
}
