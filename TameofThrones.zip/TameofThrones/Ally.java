package Practice;

public class Ally {

	private String emblem;
	
	private String getEmblem(String kingdomName) {
		emblem = Emblems.getEmblemForKingdom(kingdomName);
		return emblem;
	}

	private String getDecryptedMessage(String kingdomName, String message) {
		int cipher = getEmblem(kingdomName).length();
		String deMess = "";
		for (int i = 0; i < message.length(); ++i) {
			if (message.charAt(i) >= 'A' && message.charAt(i) <= 'Z') {
				char c = (char) ((int) message.charAt(i) - cipher);
				if (c < 'A')
					c = (char) ((int) c + Constants.ALPHABET_COUNT);
				else if (c > 'Z')
					c = (char) ((int) c - Constants.ALPHABET_COUNT);
				deMess += c;
			}
		}
		return deMess;
	}

	public boolean isAlly(String kingdomName, String message) {
		String decMessage = getDecryptedMessage(kingdomName, message);
		StringBuilder dec = new StringBuilder(decMessage);
		for (Character ch : emblem.toUpperCase().toCharArray()) {
			int charIndex = dec.indexOf(String.valueOf(ch));
			
			if (charIndex == -1)
				return false;
			else
				dec.deleteCharAt(charIndex);
		}
		return true;
	}

}
