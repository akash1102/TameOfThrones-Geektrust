package Practice;

import java.io.IOException;
import java.util.ArrayList;

public class test {

	public static void main(String[] args) throws IOException {
		
		FileReader fileReader = new FileReader();
		ArrayList<Kingdom> kingdoms = fileReader.ReadFile("input.txt");
		
		KindomAlly kingdomAlly = new KindomAlly();
		kingdomAlly.validateAllies(kingdoms);
		kingdomAlly.PrintAllies();
		
	}

}
