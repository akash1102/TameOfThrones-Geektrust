package Practice;

public class Emblems {

	public static String getEmblemForKingdom(String kingdomName) {
		switch (kingdomName) {
		case "AIR":
			return "Owl";
		case "SPACE":
			return "Gorrilla";
		case "LAND":
			return "Panda";
		case "WATER":
			return "Octopus";
		case "FIRE":
			return "Dragon";
		case "ICE":
			return "Mammoth";
		}
		return "";
	}
}
