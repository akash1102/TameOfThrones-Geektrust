package Practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class FileReader {

	public ArrayList<Kingdom> ReadFile(String fileName) throws IOException {
		InputStream inputStream = test.class.getResourceAsStream(fileName);
		BufferedReader bufferedReader = new BufferedReader(new java.io.InputStreamReader(inputStream));
		String st;
		
		ArrayList<Kingdom> kingdoms = new ArrayList<Kingdom>();
		
		while ((st = bufferedReader.readLine()) != null) {
			Kingdom kingdom = new Kingdom(st.split(" ")[0], st.split(" ")[1]);
			kingdoms.add(kingdom);
		}
		
		bufferedReader.close();
		
		return kingdoms;
		
	}
}
