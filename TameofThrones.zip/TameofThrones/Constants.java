package Practice;

public final class Constants {
	public static final int ALPHABET_COUNT = 26;
	public static final String NONE = "NONE";
	public final static int MIN_ALLIES = 3;
}
